package br.com.myCarApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyCarAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyCarAppApplication.class, args);
	}

}
